--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_user_group_fk_fkey;
ALTER TABLE ONLY public.tbl_users_services DROP CONSTRAINT tbl_users_services_user_fk_fkey;
ALTER TABLE ONLY public.tbl_users_services DROP CONSTRAINT tbl_users_services_service_fk_fkey;
ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_user_krb_name_key;
ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_user_ident_key;
ALTER TABLE ONLY public.tbl_users_services DROP CONSTRAINT tbl_users_services_pkey;
ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_pkey;
ALTER TABLE ONLY public.tbl_users_groups DROP CONSTRAINT tbl_users_groups_user_group_name_key;
ALTER TABLE ONLY public.tbl_users_groups DROP CONSTRAINT tbl_users_groups_pkey;
ALTER TABLE ONLY public.tbl_services DROP CONSTRAINT tbl_services_service_name_key;
ALTER TABLE ONLY public.tbl_services DROP CONSTRAINT tbl_services_pkey;
ALTER TABLE public.tbl_users_services ALTER COLUMN user_service_id DROP DEFAULT;
ALTER TABLE public.tbl_users_groups ALTER COLUMN user_group_id DROP DEFAULT;
ALTER TABLE public.tbl_users ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE public.tbl_services ALTER COLUMN service_id DROP DEFAULT;
DROP SEQUENCE public.tbl_users_user_id_seq;
DROP SEQUENCE public.tbl_users_services_user_service_id_seq;
DROP TABLE public.tbl_users_services;
DROP SEQUENCE public.tbl_users_groups_user_group_id_seq;
DROP TABLE public.tbl_users_groups;
DROP TABLE public.tbl_users;
DROP SEQUENCE public.tbl_services_service_id_seq;
DROP TABLE public.tbl_services;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tbl_services; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_services (
    service_id integer NOT NULL,
    service_name character varying(64) NOT NULL,
    service_icon character varying(64) DEFAULT 'icon.png'::character varying NOT NULL,
    service_description character varying(128) NOT NULL,
    service_url character varying(256) NOT NULL,
    service_status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    service_created date NOT NULL
);


ALTER TABLE public.tbl_services OWNER TO postgres;

--
-- Name: tbl_services_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_services_service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_services_service_id_seq OWNER TO postgres;

--
-- Name: tbl_services_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_services_service_id_seq OWNED BY tbl_services.service_id;


--
-- Name: tbl_users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_users (
    user_id bigint NOT NULL,
    user_group_fk integer NOT NULL,
    user_krb_name character varying(64) NOT NULL,
    user_ident character varying(9) NOT NULL,
    user_email character varying(128) NOT NULL,
    user_phone character varying(8),
    user_photo character varying(64) DEFAULT 'default.png'::character varying NOT NULL,
    user_gen character varying(1) NOT NULL,
    user_datebirth date NOT NULL,
    user_status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    user_created date NOT NULL,
    user_description character varying(128),
    user_lifetime integer DEFAULT 3600 NOT NULL,
    user_realname character varying(128) DEFAULT ''::character varying NOT NULL,
    user_type character varying(1) DEFAULT 'E'::character varying NOT NULL,
    user_chpssw character varying(1) DEFAULT 1 NOT NULL,
    user_token character varying(64) DEFAULT 'NO_TOKEN'::character varying
);


ALTER TABLE public.tbl_users OWNER TO postgres;

--
-- Name: tbl_users_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_users_groups (
    user_group_id integer NOT NULL,
    user_group_name character varying(32) NOT NULL,
    user_group_access character varying(128) NOT NULL,
    user_group_status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    user_group_created date NOT NULL,
    user_group_description character varying(128) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.tbl_users_groups OWNER TO postgres;

--
-- Name: tbl_users_groups_user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_users_groups_user_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_users_groups_user_group_id_seq OWNER TO postgres;

--
-- Name: tbl_users_groups_user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_users_groups_user_group_id_seq OWNED BY tbl_users_groups.user_group_id;


--
-- Name: tbl_users_services; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_users_services (
    user_service_id integer NOT NULL,
    user_fk bigint NOT NULL,
    service_fk integer NOT NULL,
    user_service_username character varying(128) DEFAULT 'NO_NAME'::character varying NOT NULL,
    user_service_rol character varying(64) DEFAULT 'NO_ROL'::character varying
);


ALTER TABLE public.tbl_users_services OWNER TO postgres;

--
-- Name: tbl_users_services_user_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_users_services_user_service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_users_services_user_service_id_seq OWNER TO postgres;

--
-- Name: tbl_users_services_user_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_users_services_user_service_id_seq OWNED BY tbl_users_services.user_service_id;


--
-- Name: tbl_users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_users_user_id_seq OWNER TO postgres;

--
-- Name: tbl_users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_users_user_id_seq OWNED BY tbl_users.user_id;


--
-- Name: service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_services ALTER COLUMN service_id SET DEFAULT nextval('tbl_services_service_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_users ALTER COLUMN user_id SET DEFAULT nextval('tbl_users_user_id_seq'::regclass);


--
-- Name: user_group_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_users_groups ALTER COLUMN user_group_id SET DEFAULT nextval('tbl_users_groups_user_group_id_seq'::regclass);


--
-- Name: user_service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_users_services ALTER COLUMN user_service_id SET DEFAULT nextval('tbl_users_services_user_service_id_seq'::regclass);


--
-- Name: tbl_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_services
    ADD CONSTRAINT tbl_services_pkey PRIMARY KEY (service_id);


--
-- Name: tbl_services_service_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_services
    ADD CONSTRAINT tbl_services_service_name_key UNIQUE (service_name);


--
-- Name: tbl_users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users_groups
    ADD CONSTRAINT tbl_users_groups_pkey PRIMARY KEY (user_group_id);


--
-- Name: tbl_users_groups_user_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users_groups
    ADD CONSTRAINT tbl_users_groups_user_group_name_key UNIQUE (user_group_name);


--
-- Name: tbl_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_pkey PRIMARY KEY (user_id);


--
-- Name: tbl_users_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users_services
    ADD CONSTRAINT tbl_users_services_pkey PRIMARY KEY (user_service_id);


--
-- Name: tbl_users_user_ident_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_user_ident_key UNIQUE (user_ident);


--
-- Name: tbl_users_user_krb_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_user_krb_name_key UNIQUE (user_krb_name);


--
-- Name: tbl_users_services_service_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_users_services
    ADD CONSTRAINT tbl_users_services_service_fk_fkey FOREIGN KEY (service_fk) REFERENCES tbl_services(service_id);


--
-- Name: tbl_users_services_user_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_users_services
    ADD CONSTRAINT tbl_users_services_user_fk_fkey FOREIGN KEY (user_fk) REFERENCES tbl_users(user_id);


--
-- Name: tbl_users_user_group_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_user_group_fk_fkey FOREIGN KEY (user_group_fk) REFERENCES tbl_users_groups(user_group_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

