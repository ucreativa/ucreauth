--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_user_group_fk_fkey;
ALTER TABLE ONLY public.tbl_users_services DROP CONSTRAINT tbl_users_services_user_fk_fkey;
ALTER TABLE ONLY public.tbl_users_services DROP CONSTRAINT tbl_users_services_service_fk_fkey;
ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_user_krb_name_key;
ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_user_ident_key;
ALTER TABLE ONLY public.tbl_users_services DROP CONSTRAINT tbl_users_services_pkey;
ALTER TABLE ONLY public.tbl_users DROP CONSTRAINT tbl_users_pkey;
ALTER TABLE ONLY public.tbl_users_groups DROP CONSTRAINT tbl_users_groups_user_group_name_key;
ALTER TABLE ONLY public.tbl_users_groups DROP CONSTRAINT tbl_users_groups_pkey;
ALTER TABLE ONLY public.tbl_services DROP CONSTRAINT tbl_services_service_name_key;
ALTER TABLE ONLY public.tbl_services DROP CONSTRAINT tbl_services_pkey;
ALTER TABLE public.tbl_users_services ALTER COLUMN user_service_id DROP DEFAULT;
ALTER TABLE public.tbl_users_groups ALTER COLUMN user_group_id DROP DEFAULT;
ALTER TABLE public.tbl_users ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE public.tbl_services ALTER COLUMN service_id DROP DEFAULT;
DROP SEQUENCE public.tbl_users_user_id_seq;
DROP SEQUENCE public.tbl_users_services_user_service_id_seq;
DROP TABLE public.tbl_users_services;
DROP SEQUENCE public.tbl_users_groups_user_group_id_seq;
DROP TABLE public.tbl_users_groups;
DROP TABLE public.tbl_users;
DROP SEQUENCE public.tbl_services_service_id_seq;
DROP TABLE public.tbl_services;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tbl_services; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_services (
    service_id integer NOT NULL,
    service_name character varying(64) NOT NULL,
    service_icon character varying(64) DEFAULT 'icon.png'::character varying NOT NULL,
    service_description character varying(128) NOT NULL,
    service_url character varying(256) NOT NULL,
    service_status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    service_created date NOT NULL
);


ALTER TABLE public.tbl_services OWNER TO postgres;

--
-- Name: tbl_services_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_services_service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_services_service_id_seq OWNER TO postgres;

--
-- Name: tbl_services_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_services_service_id_seq OWNED BY tbl_services.service_id;


--
-- Name: tbl_services_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tbl_services_service_id_seq', 6, true);


--
-- Name: tbl_users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_users (
    user_id bigint NOT NULL,
    user_group_fk integer NOT NULL,
    user_krb_name character varying(64) NOT NULL,
    user_ident character varying(9) NOT NULL,
    user_email character varying(128) NOT NULL,
    user_phone character varying(8),
    user_photo character varying(64) DEFAULT 'default.png'::character varying NOT NULL,
    user_gen character varying(1) NOT NULL,
    user_datebirth date NOT NULL,
    user_status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    user_created date NOT NULL,
    user_description character varying(128),
    user_lifetime integer DEFAULT 3600 NOT NULL,
    user_realname character varying(128) DEFAULT ''::character varying NOT NULL,
    user_type character varying(1) DEFAULT 'E'::character varying NOT NULL,
    user_chpssw character varying(1) DEFAULT 1 NOT NULL,
    user_token character varying(64) DEFAULT 'NO_TOKEN'::character varying
);


ALTER TABLE public.tbl_users OWNER TO postgres;

--
-- Name: tbl_users_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_users_groups (
    user_group_id integer NOT NULL,
    user_group_name character varying(32) NOT NULL,
    user_group_access character varying(128) NOT NULL,
    user_group_status character varying(1) DEFAULT 'A'::character varying NOT NULL,
    user_group_created date NOT NULL,
    user_group_description character varying(128) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.tbl_users_groups OWNER TO postgres;

--
-- Name: tbl_users_groups_user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_users_groups_user_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_users_groups_user_group_id_seq OWNER TO postgres;

--
-- Name: tbl_users_groups_user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_users_groups_user_group_id_seq OWNED BY tbl_users_groups.user_group_id;


--
-- Name: tbl_users_groups_user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tbl_users_groups_user_group_id_seq', 1, true);


--
-- Name: tbl_users_services; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tbl_users_services (
    user_service_id integer NOT NULL,
    user_fk bigint NOT NULL,
    service_fk integer NOT NULL,
    user_service_username character varying(128) DEFAULT 'NO_NAME'::character varying NOT NULL,
    user_service_rol character varying(64) DEFAULT 'NO_ROL'::character varying
);


ALTER TABLE public.tbl_users_services OWNER TO postgres;

--
-- Name: tbl_users_services_user_service_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_users_services_user_service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_users_services_user_service_id_seq OWNER TO postgres;

--
-- Name: tbl_users_services_user_service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_users_services_user_service_id_seq OWNED BY tbl_users_services.user_service_id;


--
-- Name: tbl_users_services_user_service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tbl_users_services_user_service_id_seq', 165, true);


--
-- Name: tbl_users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tbl_users_user_id_seq OWNER TO postgres;

--
-- Name: tbl_users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_users_user_id_seq OWNED BY tbl_users.user_id;


--
-- Name: tbl_users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tbl_users_user_id_seq', 164, true);


--
-- Name: service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_services ALTER COLUMN service_id SET DEFAULT nextval('tbl_services_service_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_users ALTER COLUMN user_id SET DEFAULT nextval('tbl_users_user_id_seq'::regclass);


--
-- Name: user_group_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_users_groups ALTER COLUMN user_group_id SET DEFAULT nextval('tbl_users_groups_user_group_id_seq'::regclass);


--
-- Name: user_service_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE tbl_users_services ALTER COLUMN user_service_id SET DEFAULT nextval('tbl_users_services_user_service_id_seq'::regclass);


--
-- Data for Name: tbl_services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tbl_services (service_id, service_name, service_icon, service_description, service_url, service_status, service_created) FROM stdin;
1	correo	mail.png	Servicio de correo de la Universidad Creativa	app_core/modules/saml_sso_php/saml_core.php	A	2011-10-24
2	uvirtual	moodle.png	Control de cursos	http://10.20.30.105/moodle/login/index.php	A	2011-10-24
3	wiki	mediawiki.png	Gestor de contenido educativo	http://10.20.30.105/mediawiki/index.php?title=Special:UserLogin	A	2011-10-24
5	ucreativa	ucreativa.png	Sitio Web de la Universidad Creativa	http://www.ucreativa.com	A	2011-10-24
4	ucreadmin	ucreadmin.png	Administrador de contenido del sitio de la Universidad	http://10.20.30.105/ucreadmin/	A	2011-10-24
6	autentificacion	ucreauth.png	Servicio de autentificación y registro de Usuarios	http://201.198.138.107/ucreauth/app_core/views/control_panel.php	A	2011-10-24
\.


--
-- Data for Name: tbl_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tbl_users (user_id, user_group_fk, user_krb_name, user_ident, user_email, user_phone, user_photo, user_gen, user_datebirth, user_status, user_created, user_description, user_lifetime, user_realname, user_type, user_chpssw, user_token) FROM stdin;
1	1	uti	999	uti@ucreativa.com		default.png	M	1960-01-01	A	2011-10-24	Usuario por defecto, departamento de UTI	3600	UTI	A	0	NO_TOKEN
35	1	luis.morales	33	lumiagil@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Luis Morales	A	0	NO_TOKEN
8	1	gabriela.calvo	6	gabyyy84@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Gabriela Calvo	A	0	NO_TOKEN
7	1	paulino.blanco	5	pauliblanco@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Paulino Blanco	A	0	NO_TOKEN
2	1	uti.pruebas	777	uti.pruebas@ucreativa.com	0	default.png	M	1960-01-01	A	2011-10-24	Usuario por defecto de pruebas	3600	UTI PRUEBAS	A	0	NO_TOKEN
18	1	maicol.fallas	16	maicfa@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Maicol Fallas	A	0	NO_TOKEN
4	1	amarilys.abarca	2	aabarca88@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Amarilys Abarca	A	0	NO_TOKEN
6	1	kermit.batres	4	Kerbat@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Kermit Batres	A	0	NO_TOKEN
146	1	silvia.vargas	146	silviavvn@gmail.com	0	default.png	F	2011-01-01	A	2011-10-25	 	3600	Silvia Vargas	A	0	NO_TOKEN
9	1	valeria.castillo	7	valeriacastillosa@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Astrid Castillo	A	0	NO_TOKEN
11	1	fernanda.cerdas	9	fcerdas_92@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Fernanda Cerdas	A	0	NO_TOKEN
10	1	jean.castro	8	jnk060489@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jean Castro	A	0	NO_TOKEN
38	1	mario.navarro	36	navarro.mario@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Mario Navarro	A	0	NO_TOKEN
5	1	roxana.aguero	3	roxanaaguero@yahoo.es	0	default.png	M	2000-01-01	A	2011-10-24		3600	Roxana Agüero	A	0	NO_TOKEN
25	1	deiver.herrera	23	deiverhs@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Deiver Herrera	A	0	NO_TOKEN
157	1	mariajose.reyes	153	tania.navarro@ucreativa.com	0	default.png	F	2011-01-01	A	2011-11-03	 	3600	Maria José Reyes	A	0	NO_TOKEN
143	1	info	990	info@ucreativa.com	0	default.png	M	2011-01-01	A	2011-10-25	USER INFO DEFAULT	3600	INFO	A	0	NO_TOKEN
45	1	bryan.rojas	43	brojask@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Bryan Rojas	A	0	NO_TOKEN
147	1	monica.diaz	147	monicpds18@gmail.com	0	default.png	M	2011-01-01	A	2011-10-25	 	3600	Mónica Diaz	A	0	NO_TOKEN
154	1	irene.castillo	151	irecastillo@gmail.com	0	default.png	F	2011-01-01	A	2011-11-01	 	3600	Irene Castillo	A	0	NO_TOKEN
130	1	ifigenia.scorza	128	arqiscorza@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Ifigenia Scorza	A	0	NO_TOKEN
21	1	jordan.garcia	19	jordan-gv@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jordan Garcia	A	0	NO_TOKEN
28	1	mauricio.jimenez	26	mjimenez2306@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Mauricio Jiménez	A	0	NO_TOKEN
14	1	carlos.delao	12	carlos.delao.herrera@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Carlos DelaO	A	0	NO_TOKEN
27	1	luis.hernandez	25	luisva07@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Luis Hernández	A	0	NO_TOKEN
19	1	allan.fernandez	17	allanfernandez@racsa.co.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Allan Fernández	A	0	NO_TOKEN
144	1	vanesa.segura	144	vanne_howell@hotmail.com	0	default.png	F	2011-01-01	A	2011-10-25	 	3600	Vannesa Segura	A	0	NO_TOKEN
22	1	andrea.gatjens	20	agatjens@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Andrea Gatjens	A	0	NO_TOKEN
13	1	paola.chaverri	11	pao.ch.z@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Paola Chaverrí	A	0	NO_TOKEN
26	1	fernanda.hernandez	24	fernan_22-10-92@hotmail.es	0	default.png	M	2000-01-01	A	2011-10-24		3600	Fernanda Hernández	A	0	NO_TOKEN
23	1	olman.guadamuz	21	olgus20@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Olman Guadamuz	A	0	NO_TOKEN
148	1	ana.chacon	148	ana.chacon@ucreativa.com	0	default.png	M	2011-01-01	A	2011-10-25	 	3600	Ana Yancy Chacón	A	0	NO_TOKEN
24	1	amira.jalet	22	amijalet@yahoo.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Amira Jalet	A	0	NO_TOKEN
20	1	jose.fernandez	18	jfernandez4@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jose Fernández	A	0	NO_TOKEN
12	1	isamara.cortes	10	fisa_cortez18@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Isamara Cortés	A	0	NO_TOKEN
29	1	maria.madrigal	27	mariamadrigal2000@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	María Madrigal	A	0	NO_TOKEN
15	1	cindy.depaz	13	depazq_ce@yahoo.es	0	default.png	M	2000-01-01	A	2011-10-24		3600	Cindy Depaz	A	1	NO_TOKEN
16	1	andrea.diaz	14	andigu_4@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Andrea Diaz	A	1	NO_TOKEN
17	1	bryan.diaz	15	bdiazcr@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Bryan Diaz	A	1	NO_TOKEN
103	1	gabriela.miranda	101	gbmiranda@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Gabriela Miranda	A	1	NO_TOKEN
33	1	josemiguel.melendez	31	jose_melendez_m@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jose Melendez	A	1	NO_TOKEN
55	1	laura.aguilar	53	aguilarcarvjallaura@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Laura Aguilar	A	1	NO_TOKEN
57	1	mariafe.alpizar	55	mrmsol@racsa.co.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	MariaFe Alpizar	A	1	NO_TOKEN
59	1	fabian.alpizar	57	fabiangrid@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Fabian Alpizar	A	1	NO_TOKEN
60	1	william.alvarez	58	will.alvarezsanabria@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	William Alvarez	A	1	NO_TOKEN
62	1	sebastian.arce	60	sebasarce86@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Sebastian Arce	A	1	NO_TOKEN
63	1	anamaria.araujo	61	aaraujo@arkitektos.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	AnaMaría Araujo	A	1	NO_TOKEN
64	1	ricardo.bolanos	62	rik.ucreativa@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Ricardo Bolaños	A	1	NO_TOKEN
65	1	elena.balma	63	elena.bol.rol@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Elena Balma	A	1	NO_TOKEN
66	1	juanpablo.calvo	64	valgaer@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	JuanPablo Calvo	A	1	NO_TOKEN
67	1	roger.calvo	65	roger_calvo@yahoo.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Roger Calvo	A	1	NO_TOKEN
68	1	jovanny.cambronero	66	jova_1004@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jovanny Cambronero	A	1	NO_TOKEN
71	1	jorge.cisneros	69	arq.jcisneros@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jorge Cisneros	A	1	NO_TOKEN
72	1	daniel.colombari	70	dcucreativa@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Daniel Colombari	A	1	NO_TOKEN
75	1	oscar.cuevas	73	unknown@unknown.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Oscar Cuevas	A	1	NO_TOKEN
77	1	bryan.diaz1	75	bdiaz@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Bryan Diaz	A	1	NO_TOKEN
78	1	luis.esquivel	76	diegoesquivel7@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Luis Esquivel	A	1	NO_TOKEN
79	1	esteban.elizondo	77	estelizondo@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Esteban Elizondo	A	1	NO_TOKEN
80	1	marcela.esquivel	78	maresjim@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Marcela Esquivel	A	1	NO_TOKEN
82	1	erick.fallas	80	erickfa@racsa.co.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Erick Fallas	A	1	NO_TOKEN
83	1	andres.fernandez	81	cualquierbara@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Andres Fernandez	A	1	NO_TOKEN
85	1	alvaro.fonseca	83	afonseca@fonzstudio.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Alvaro Fonseca	A	1	NO_TOKEN
86	1	henry.fonseca	84	hafonsecamora@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Henry Fonseca	A	1	NO_TOKEN
90	1	adriana.guzman	88	adriana.guzman22@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Adriana Guzman	A	1	NO_TOKEN
92	1	diana.harari	90	hararidiana@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Diana Harari	A	1	NO_TOKEN
93	1	nelson.heymans	91	nelson.upe@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Nelson Heymans	A	1	NO_TOKEN
34	1	william.moraga	32	william.moraga@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	William Moraga	A	0	NO_TOKEN
56	1	marcela.alarcon	54	marcelaalarcon@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Marcela Alarcon	A	0	NO_TOKEN
39	1	tania.navarro	37	tania_cr06@yahoo.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Tania Navarro	A	0	NO_TOKEN
44	1	daniel.rodriguez	42	dani_oni@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Daniel Rodriguez	A	0	NO_TOKEN
53	1	josecarlo.vargas	51	jcvargas_2792@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jose Carlo Vargas	A	0	NO_TOKEN
48	1	roney.sequeira	46	ronseque@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Roney Sequeira	A	0	NO_TOKEN
47	1	laura.rojas	45	laurajasi@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Laura Rojas	A	0	NO_TOKEN
3	1	bryan.abarca	1	bmigueamador@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Bryan Abarca	A	0	NO_TOKEN
54	1	fabian.zaldivar	52	fabianzaldivar@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Fabian Zaldivar	A	0	NO_TOKEN
49	1	diego.sinfonte	47	groover@hotmail.es	0	default.png	M	2000-01-01	A	2011-10-24		3600	Diego Sinfonte	A	0	NO_TOKEN
36	1	melanny.murillo	34	mela-1987@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Melany Murrillo	A	0	NO_TOKEN
42	1	carlos.perez	40	carlos.perezl@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Carlos Perez	A	0	NO_TOKEN
43	1	oscar.quesada	41	oscarbravo_26@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Oscar Quesada	A	0	NO_TOKEN
41	1	kenia.padilla	39	kenraq47@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Kenia Padilla	A	0	NO_TOKEN
37	1	priscilla.murillo	35	buzongab@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Priscilla Murillo	A	0	NO_TOKEN
51	1	mariaeugenia.varela	49	maria.eugenia42@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	María Varela	A	0	NO_TOKEN
52	1	javier.valerin	50	francisco.valerin@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Javier Valerin	A	0	NO_TOKEN
70	1	maurenne.chavarria	68	maur060379@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Maurenne Chavarria	A	0	NO_TOKEN
69	1	andrea.carranza	67	andycarranza@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Andrea Carranza	A	0	NO_TOKEN
40	1	adelso.ortega	38	adelsorteg@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Adelso Ortega	A	0	NO_TOKEN
88	1	pablo.granados	86	pablogra187@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Pablo Granados	A	0	NO_TOKEN
58	1	carolina.alpizar	56	caralpnu@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Carolina Alpizar	A	0	NO_TOKEN
31	1	gabriela.marin	29	amayda.marin@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Gabriela Marín	A	0	NO_TOKEN
30	1	roberto.madrigal	28	rodmad@ice.co.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Roberto Madrigal	A	0	NO_TOKEN
84	1	miguel.fernandez	82	miguelf1717@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Miguel Fernandez	A	0	NO_TOKEN
32	1	giselle.melendez	30	guisellemelendezm@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Giselle Meléndez	A	0	NO_TOKEN
94	1	alejandro.irias	92	iriasalejandro@yahoo.es	0	default.png	M	2000-01-01	A	2011-10-24		3600	Alejandro Irias	A	1	NO_TOKEN
95	1	silvia.jiron	93	silviajironc@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Silvia Jiron	A	1	NO_TOKEN
96	1	mario.leiva	94	leivagmario@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Mario Leiva	A	1	NO_TOKEN
97	1	diego.levinson	95	iegolevinson@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Diego Levinson	A	1	NO_TOKEN
99	1	ivania.madrigal	97	iva.m.u@homail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Ivania Madrigal	A	1	NO_TOKEN
100	1	silvia.marin	98	silvia@arquen.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Silvia Marin	A	1	NO_TOKEN
101	1	felipe.martinez	99	afelipems@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Felipe Martinez	A	1	NO_TOKEN
102	1	etzia.mejia	100	etziamejia@ice.co.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Etzia Mejia	A	1	NO_TOKEN
87	1	hernan.gonzalez	85	hernangster@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Hernan Gonzalez	A	1	NO_TOKEN
73	1	minor.cortez	71	mcortes777@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Minor Cortes	A	1	NO_TOKEN
106	1	ivan.moreno	104	imoreno@demarcacr.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Ivan Moreno	A	1	NO_TOKEN
107	1	alvaro.nunez	105	anunez@vestuarioin.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Alvaro Nuñez	A	1	NO_TOKEN
91	1	wendy.hall	89	wendyhallfdez@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Wendy Hall	A	0	NO_TOKEN
89	1	dafna.grynspan	87	dafnagrynspan@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Dafna Grynspan	A	0	NO_TOKEN
108	1	mariajose.nunez	106	dilupcr@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	MariaJosé Nuñez	A	1	NO_TOKEN
109	1	daniel.obando	107	daniel.obf@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Daniel Obando	A	1	NO_TOKEN
110	1	michael.ocampo	108	michaelocampo@live.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Michael Ocampo	A	1	NO_TOKEN
111	1	geanina.oviedo	109	goviedo@marinc.co	0	default.png	M	2000-01-01	A	2011-10-24		3600	Geanina Oviedo	A	1	NO_TOKEN
113	1	alejandro.peraza	111	aperazza@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Alejandro Peraza	A	1	NO_TOKEN
114	1	randall.picado	112	ranpicado@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Randall Picado	A	1	NO_TOKEN
115	1	carlos.quesada	113	carlos@carlosqphoto.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Carlos Quesada	A	1	NO_TOKEN
120	1	lina.rodriguez	118	lina.rv@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Lina Rodriguez	A	1	NO_TOKEN
121	1	josemanuel.rojas	119	joserora@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	JoseManuel Rojas	A	1	NO_TOKEN
122	1	dalia.rojas	120	alisrojis@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Dalia Rojas	A	1	NO_TOKEN
123	1	eddy.rojas	121	spectroimage@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Eddy Rojas	A	1	NO_TOKEN
124	1	mario.rojas	122	smariorojaskolomiets@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Mario Rojas	A	1	NO_TOKEN
125	1	miguel.romano	123	romanosandi@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Miguel Romano	A	1	NO_TOKEN
126	1	andres.salas	124	salas.andres@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Andres Salas	A	1	NO_TOKEN
127	1	bryan.salazar	125	briansv@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Bryan Salazar	A	1	NO_TOKEN
128	1	julio.salazar	126	juliodracoinc@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Julio Salazar	A	1	NO_TOKEN
129	1	randall.solis	127	rasolis28@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Randall Solis	A	1	NO_TOKEN
131	1	natalia.solano	129	carambolagroup@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Natalia Solano	A	1	NO_TOKEN
132	1	gabriela.soto	130	gsoto@cfia.or.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Gabriela Soto	A	1	NO_TOKEN
134	1	esteban.tobon	132	toboncampo@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Esteban Tobon	A	1	NO_TOKEN
135	1	oscar.trejos	133	otrejosj@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Oscar Trejos	A	1	NO_TOKEN
136	1	lourdes.vargas	134	lourdesvargasmorandi@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Lourdes Vargas	A	1	NO_TOKEN
137	1	olman.vargas	135	olmanvb@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Olman Vargas	A	1	NO_TOKEN
138	1	rafael.vargas	136	rvargas@poder-judicial.go.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Rafael Vargas	A	1	NO_TOKEN
140	1	rudolf.wedel	138	rwedel@hotmail.es	0	default.png	M	2000-01-01	A	2011-10-24		3600	Rudolf Wedel	A	1	NO_TOKEN
141	1	maikol.zamora	139	mazara03@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Maikol Zamora	A	1	NO_TOKEN
142	1	carmen.zuniga 	140	cmarquitectura.march@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Carmen Zuñiga	A	1	NO_TOKEN
76	1	francisco.delapena	74	fran@fran.cr	0	default.png	M	2000-01-01	A	2011-10-24		3600	Francisco DelaPeña	A	1	NO_TOKEN
133	1	mariano.tanco	131	mtancoch@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Mariano Tanco	A	1	NO_TOKEN
50	1	enrique.umana	48	enrique.umana@yahoo.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Enrique Umaña	A	0	NO_TOKEN
145	1	esteban.sabat	145	esabatz@gmail.com	0	default.png	M	2011-01-01	A	2011-10-25	 	3600	Esteban Sabat	A	0	NO_TOKEN
104	1	gloria.montalto	102	glo_montalto@msn.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Gloria Montalto	A	0	NO_TOKEN
117	1	antony.quiros	115	antquilo@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Antony Quiros	A	0	NO_TOKEN
98	1	paulo.lopez	96	lqpaulo@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Paulo Lopez	A	0	NO_TOKEN
119	1	belma.renick	117	belmarenick@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Belma Renick	A	0	NO_TOKEN
105	1	herminio.montero	103	herminiomc@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Herminio Montero	A	0	NO_TOKEN
46	1	oscar.romero	44	oskarelo@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Oscar Romero	A	0	NO_TOKEN
118	1	mikel.ramirez	116	mklrm@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Mikel Ramírez	A	0	NO_TOKEN
116	1	jonathan.quesada	114	quesadajonathan@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Jonathan Quesada	A	0	NO_TOKEN
81	1	admisiones.zapote	79	admisiones.zapote@ucreativa.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Admisiones Zapote	A	0	NO_TOKEN
152	1	creatipos	149	creatipos@ucreativa.com	0	default.png	M	2011-01-01	A	2011-10-31	 	3600	Creatipos	A	0	NO_TOKEN
112	1	melania.palacios	110	melapalacios@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Melania Palacios	A	0	NO_TOKEN
139	1	ricardo.walker	137	icardowalkerbarnes@hotmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Ricardo Walker	A	0	NO_TOKEN
156	1	anaelena.balma	789	aebalma@gmail.com	1	default.png	F	2011-01-01	A	2011-11-03		3600	Ana Elena Balma	P	1	NO_TOKEN
61	1	ifat.amit	59	ifamit@gmail.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Ifat Amit	A	0	NO_TOKEN
161	1	priscila.zuniga	158	enrique.umana@ucreativa.com	1	default.png	M	2011-01-01	A	2011-11-07		3600	priscila.zuniga	A	1	NO_TOKEN
162	1	tania.devoto	159	tania@grandecentroamerica.com	1	default.png	F	2011-01-01	A	2011-11-07		3600	Tania Devoto	E	1	NO_TOKEN
163	1	sara.martinez	160	sarmaga33@yahoo.es	1	default.png	F	2011-01-01	A	2011-11-07		3600	Sara Martinez	A	1	NO_TOKEN
164	1	helena.bolanos	161	helena.bol.rol@gmail.com	1	default.png	F	2011-01-01	A	2011-11-07		3600	Helena Bolaños	E	1	NO_TOKEN
74	1	veronica.cruz	72	verocruz@nadacomun.com	0	default.png	M	2000-01-01	A	2011-10-24		3600	Veronica Cruz	A	0	NO_TOKEN
158	1	maria.ruzicka	155	ruzickamajo@gmail.com	1	default.png	F	2011-01-01	A	2011-11-07		3600	María José Ruzicka	P	0	NO_TOKEN
\.


--
-- Data for Name: tbl_users_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tbl_users_groups (user_group_id, user_group_name, user_group_access, user_group_status, user_group_created, user_group_description) FROM stdin;
1	STANDARD	[]	A	2011-10-24	Grupo con privilegios base estándar
\.


--
-- Data for Name: tbl_users_services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tbl_users_services (user_service_id, user_fk, service_fk, user_service_username, user_service_rol) FROM stdin;
1	1	1	NO_NAME	NO_ROL
2	2	1	NO_NAME	NO_ROL
3	2	2	admin	ADMINISTRADOR
4	2	3	Wikiadmin	ADMINISTRADOR
5	2	4	adminuc	ADMINISTRADOR
6	2	5	NO_NAME	NO_ROL
7	2	6	NO_NAME	NO_ROL
8	3	1	NO_NAME	NO_ROL
9	4	1	NO_NAME	NO_ROL
10	5	1	NO_NAME	NO_ROL
11	6	1	NO_NAME	NO_ROL
12	7	1	NO_NAME	NO_ROL
13	8	1	NO_NAME	NO_ROL
14	9	1	NO_NAME	NO_ROL
15	10	1	NO_NAME	NO_ROL
16	11	1	NO_NAME	NO_ROL
17	12	1	NO_NAME	NO_ROL
18	13	1	NO_NAME	NO_ROL
19	14	1	NO_NAME	NO_ROL
20	15	1	NO_NAME	NO_ROL
21	16	1	NO_NAME	NO_ROL
22	17	1	NO_NAME	NO_ROL
23	18	1	NO_NAME	NO_ROL
24	19	1	NO_NAME	NO_ROL
25	20	1	NO_NAME	NO_ROL
26	21	1	NO_NAME	NO_ROL
27	22	1	NO_NAME	NO_ROL
28	23	1	NO_NAME	NO_ROL
29	24	1	NO_NAME	NO_ROL
30	25	1	NO_NAME	NO_ROL
31	26	1	NO_NAME	NO_ROL
32	27	1	NO_NAME	NO_ROL
33	28	1	NO_NAME	NO_ROL
34	29	1	NO_NAME	NO_ROL
35	30	1	NO_NAME	NO_ROL
36	31	1	NO_NAME	NO_ROL
37	32	1	NO_NAME	NO_ROL
38	33	1	NO_NAME	NO_ROL
39	34	1	NO_NAME	NO_ROL
40	35	1	NO_NAME	NO_ROL
41	36	1	NO_NAME	NO_ROL
42	37	1	NO_NAME	NO_ROL
43	38	1	NO_NAME	NO_ROL
44	39	1	NO_NAME	NO_ROL
45	40	1	NO_NAME	NO_ROL
46	41	1	NO_NAME	NO_ROL
47	42	1	NO_NAME	NO_ROL
48	43	1	NO_NAME	NO_ROL
49	44	1	NO_NAME	NO_ROL
50	45	1	NO_NAME	NO_ROL
51	46	1	NO_NAME	NO_ROL
52	47	1	NO_NAME	NO_ROL
53	48	1	NO_NAME	NO_ROL
54	49	1	NO_NAME	NO_ROL
55	50	1	NO_NAME	NO_ROL
56	51	1	NO_NAME	NO_ROL
57	52	1	NO_NAME	NO_ROL
58	53	1	NO_NAME	NO_ROL
59	54	1	NO_NAME	NO_ROL
60	55	1	NO_NAME	NO_ROL
61	56	1	NO_NAME	NO_ROL
62	57	1	NO_NAME	NO_ROL
63	58	1	NO_NAME	NO_ROL
64	59	1	NO_NAME	NO_ROL
65	60	1	NO_NAME	NO_ROL
66	61	1	NO_NAME	NO_ROL
67	62	1	NO_NAME	NO_ROL
68	63	1	NO_NAME	NO_ROL
69	64	1	NO_NAME	NO_ROL
70	65	1	NO_NAME	NO_ROL
71	66	1	NO_NAME	NO_ROL
72	67	1	NO_NAME	NO_ROL
73	68	1	NO_NAME	NO_ROL
74	69	1	NO_NAME	NO_ROL
75	70	1	NO_NAME	NO_ROL
76	71	1	NO_NAME	NO_ROL
77	72	1	NO_NAME	NO_ROL
78	73	1	NO_NAME	NO_ROL
79	74	1	NO_NAME	NO_ROL
80	75	1	NO_NAME	NO_ROL
81	76	1	NO_NAME	NO_ROL
82	77	1	NO_NAME	NO_ROL
83	78	1	NO_NAME	NO_ROL
84	79	1	NO_NAME	NO_ROL
85	80	1	NO_NAME	NO_ROL
86	81	1	NO_NAME	NO_ROL
87	82	1	NO_NAME	NO_ROL
88	83	1	NO_NAME	NO_ROL
89	84	1	NO_NAME	NO_ROL
90	85	1	NO_NAME	NO_ROL
91	86	1	NO_NAME	NO_ROL
92	87	1	NO_NAME	NO_ROL
93	88	1	NO_NAME	NO_ROL
94	89	1	NO_NAME	NO_ROL
95	90	1	NO_NAME	NO_ROL
96	91	1	NO_NAME	NO_ROL
97	92	1	NO_NAME	NO_ROL
98	93	1	NO_NAME	NO_ROL
99	94	1	NO_NAME	NO_ROL
100	95	1	NO_NAME	NO_ROL
101	96	1	NO_NAME	NO_ROL
102	97	1	NO_NAME	NO_ROL
103	98	1	NO_NAME	NO_ROL
104	99	1	NO_NAME	NO_ROL
105	100	1	NO_NAME	NO_ROL
106	101	1	NO_NAME	NO_ROL
107	102	1	NO_NAME	NO_ROL
108	103	1	NO_NAME	NO_ROL
109	104	1	NO_NAME	NO_ROL
110	105	1	NO_NAME	NO_ROL
111	106	1	NO_NAME	NO_ROL
112	107	1	NO_NAME	NO_ROL
113	108	1	NO_NAME	NO_ROL
114	109	1	NO_NAME	NO_ROL
115	110	1	NO_NAME	NO_ROL
116	111	1	NO_NAME	NO_ROL
117	112	1	NO_NAME	NO_ROL
118	113	1	NO_NAME	NO_ROL
119	114	1	NO_NAME	NO_ROL
120	115	1	NO_NAME	NO_ROL
121	116	1	NO_NAME	NO_ROL
122	117	1	NO_NAME	NO_ROL
123	118	1	NO_NAME	NO_ROL
124	119	1	NO_NAME	NO_ROL
125	120	1	NO_NAME	NO_ROL
126	121	1	NO_NAME	NO_ROL
127	122	1	NO_NAME	NO_ROL
128	123	1	NO_NAME	NO_ROL
129	124	1	NO_NAME	NO_ROL
130	125	1	NO_NAME	NO_ROL
131	126	1	NO_NAME	NO_ROL
132	127	1	NO_NAME	NO_ROL
133	128	1	NO_NAME	NO_ROL
134	129	1	NO_NAME	NO_ROL
135	130	1	NO_NAME	NO_ROL
136	131	1	NO_NAME	NO_ROL
137	132	1	NO_NAME	NO_ROL
138	133	1	NO_NAME	NO_ROL
139	134	1	NO_NAME	NO_ROL
140	135	1	NO_NAME	NO_ROL
141	136	1	NO_NAME	NO_ROL
142	137	1	NO_NAME	NO_ROL
143	138	1	NO_NAME	NO_ROL
144	139	1	NO_NAME	NO_ROL
145	140	1	NO_NAME	NO_ROL
146	141	1	NO_NAME	NO_ROL
147	142	1	NO_NAME	NO_ROL
148	143	1	NO_NAME	NO_ROL
149	144	1	NO_NAME	NO_ROL
150	145	1	NO_NAME	NO_ROL
151	146	1	NO_NAME	NO_ROL
152	147	1	NO_NAME	NO_ROL
153	148	1	NO_NAME	NO_ROL
154	152	1	NO_NAME	NO_ROL
156	154	1	NO_NAME	NO_ROL
158	156	1	NO_NAME	NO_ROL
159	157	1	NO_NAME	NO_ROL
160	1	6	NO_NAME	NO_ROL
161	158	1	NO_NAME	NO_ROL
162	161	1	NO_NAME	NO_ROL
163	162	1	NO_NAME	NO_ROL
164	163	1	NO_NAME	NO_ROL
165	164	1	NO_NAME	NO_ROL
\.


--
-- Name: tbl_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_services
    ADD CONSTRAINT tbl_services_pkey PRIMARY KEY (service_id);


--
-- Name: tbl_services_service_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_services
    ADD CONSTRAINT tbl_services_service_name_key UNIQUE (service_name);


--
-- Name: tbl_users_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users_groups
    ADD CONSTRAINT tbl_users_groups_pkey PRIMARY KEY (user_group_id);


--
-- Name: tbl_users_groups_user_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users_groups
    ADD CONSTRAINT tbl_users_groups_user_group_name_key UNIQUE (user_group_name);


--
-- Name: tbl_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_pkey PRIMARY KEY (user_id);


--
-- Name: tbl_users_services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users_services
    ADD CONSTRAINT tbl_users_services_pkey PRIMARY KEY (user_service_id);


--
-- Name: tbl_users_user_ident_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_user_ident_key UNIQUE (user_ident);


--
-- Name: tbl_users_user_krb_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_user_krb_name_key UNIQUE (user_krb_name);


--
-- Name: tbl_users_services_service_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_users_services
    ADD CONSTRAINT tbl_users_services_service_fk_fkey FOREIGN KEY (service_fk) REFERENCES tbl_services(service_id);


--
-- Name: tbl_users_services_user_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_users_services
    ADD CONSTRAINT tbl_users_services_user_fk_fkey FOREIGN KEY (user_fk) REFERENCES tbl_users(user_id);


--
-- Name: tbl_users_user_group_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_users
    ADD CONSTRAINT tbl_users_user_group_fk_fkey FOREIGN KEY (user_group_fk) REFERENCES tbl_users_groups(user_group_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

